var searchData=
[
  ['eleccio_5fcpu_0',['eleccio_cpu',['../classCluster.html#abf09171f14a1b2eb62bf4a23fefb1c55',1,'Cluster']]],
  ['enviar_5fprocesos_5fcluster_1',['enviar_procesos_cluster',['../classArea__de__espera.html#ac05e5a7ce11d38c1ea81e20f83d45ba8',1,'Area_de_espera::enviar_procesos_cluster()'],['../classPrioritat.html#a3132a498aa7460757adfa52ca9e8e08b',1,'Prioritat::enviar_procesos_cluster()']]],
  ['existeix_5fcpu_2',['existeix_cpu',['../classCluster.html#a610fcaa067567d331aedbffe71e88f6f',1,'Cluster']]],
  ['existeix_5fprioritat_3',['existeix_prioritat',['../classArea__de__espera.html#aa8e6f0e19a6cd5850d82e407f3351f1b',1,'Area_de_espera::existeix_prioritat(const string &amp;ID_Prioritat) const'],['../classArea__de__espera.html#a16fba4324a75cfddd644e7a7e5713c74',1,'Area_de_espera::existeix_prioritat(const string &amp;ID_Prioritat, map&lt; string, Prioritat &gt;::iterator &amp;it)']]],
  ['existeix_5fproces_4',['existeix_proces',['../classCpu.html#a96804d325cde940d278d790970043f0b',1,'Cpu::existeix_proces()'],['../classPrioritat.html#ab55b41d0a056de6d90967d65b6824cb3',1,'Prioritat::existeix_proces(const int &amp;proces) const']]],
  ['existeixen_5fprocessos_5',['existeixen_processos',['../classPrioritat.html#a6bf4c07e9945b73dc549f5c24565f317',1,'Prioritat']]]
];

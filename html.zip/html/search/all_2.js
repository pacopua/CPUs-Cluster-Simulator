var searchData=
[
  ['capacitat_0',['capacitat',['../classCpu.html#a4bfda8eaab4988e20240ace423a1d21c',1,'Cpu']]],
  ['checkear_5farbol_5fdist_5fesqu_1',['checkear_arbol_dist_esqu',['../classCluster.html#a993231ce1916469634c250c480fce9af',1,'Cluster']]],
  ['cluster_2',['Cluster',['../classCluster.html',1,'Cluster'],['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster::Cluster()']]],
  ['cluster_2ecc_3',['Cluster.cc',['../Cluster_8cc.html',1,'']]],
  ['cluster_2ehh_4',['Cluster.hh',['../Cluster_8hh.html',1,'']]],
  ['compactar_5fmemoria_5fcluster_5',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fcpu_6',['compactar_memoria_cpu',['../classCluster.html#a6f7b8f452f28cbc24577c1967b64c345',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_7',['compactar_memoria_procesador',['../classCpu.html#a40a769ac72a577eb0a5d54782f259deb',1,'Cpu']]],
  ['configurar_5fcluster_8',['configurar_cluster',['../classCluster.html#a84f9daea57e2773ab5766ef82d2a1def',1,'Cluster']]],
  ['consultar_5fid_9',['consultar_ID',['../classCpu.html#ab44019f54b0d0e0ab2b7987890995a2e',1,'Cpu::consultar_ID()'],['../classPrioritat.html#a990a871bdeffb1dc80e5f451fa9656f7',1,'Prioritat::consultar_ID()'],['../classProces.html#a5a3a3957e5be0f7b5030a852124021d2',1,'Proces::consultar_ID() const']]],
  ['consultar_5fmemoria_10',['consultar_memoria',['../classProces.html#af7701988b05c032f93fbd0e22abf3fd5',1,'Proces']]],
  ['consultar_5fmemoria_5flliure_11',['consultar_memoria_lliure',['../classCpu.html#a0f504f4b76feb9818115c565efc3fe40',1,'Cpu']]],
  ['consultar_5ftemps_12',['consultar_temps',['../classProces.html#af8501597189c25ca280c984a5d086d02',1,'Proces']]],
  ['cpu_13',['Cpu',['../classCpu.html#aee3f1f0f2f4d85e2681af1e225c8712e',1,'Cpu::Cpu()'],['../classCpu.html',1,'Cpu']]],
  ['cpu_2ecc_14',['Cpu.cc',['../Cpu_8cc.html',1,'']]],
  ['cpu_2ehh_15',['Cpu.hh',['../Cpu_8hh.html',1,'']]],
  ['cpu_5fexisteix_5fproces_16',['cpu_existeix_proces',['../classCluster.html#a8d818c98e30670b28a6ef8ba7b4669d4',1,'Cluster']]],
  ['cpu_5fte_5fprocesos_17',['cpu_te_procesos',['../classCluster.html#a435591fe0dfb1e61e477d0c7ee9814aa',1,'Cluster']]]
];

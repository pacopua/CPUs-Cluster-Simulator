var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fcluster_1',['modificar_cluster',['../classCluster.html#a149f8bf9acccecfce34bfc4f5a09b282',1,'Cluster']]],
  ['modificar_5ftemps_2',['modificar_temps',['../classProces.html#aaba46505d9faf344bb33e755c574a4ba',1,'Proces']]]
];

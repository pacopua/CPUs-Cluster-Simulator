var searchData=
[
  ['imprimir_0',['imprimir',['../classProces.html#a65b5b63f01bc0be96d2be54ff90bc987',1,'Proces']]],
  ['imprimir_5farea_5fespera_1',['imprimir_area_espera',['../classArea__de__espera.html#abb8a42b756eb6ec839b1ad514eed3b43',1,'Area_de_espera']]],
  ['imprimir_5festructura_2',['imprimir_estructura',['../classCluster.html#ad6e93a4a1a6f2e9228b5e30962b4ac06',1,'Cluster']]],
  ['imprimir_5fid_3',['imprimir_ID',['../classCpu.html#ae4b77431b71b0cabd384566ebfe24d81',1,'Cpu']]],
  ['imprimir_5fprioridad_4',['imprimir_prioridad',['../classArea__de__espera.html#ade30d0c4340bbace809fdf5074c515ac',1,'Area_de_espera::imprimir_prioridad()'],['../classPrioritat.html#acbd167ca58481a599da536086981741b',1,'Prioritat::imprimir_prioridad()']]],
  ['imprimir_5fprocesador_5',['imprimir_procesador',['../classCluster.html#a2568d0369b17835721a85ead28637d5f',1,'Cluster::imprimir_procesador()'],['../classCpu.html#a5eb8b3c4af9d015bc41370cac5fabe1c',1,'Cpu::imprimir_procesador()']]],
  ['imprimir_5fprocesadores_6',['imprimir_procesadores',['../classCluster.html#afc3924fd1f4643746ec3757c7777d732',1,'Cluster']]],
  ['inmersio_5fmodificar_5fcluster_7',['inmersio_modificar_cluster',['../classCluster.html#abe760c9557b5aaabc8cfb921f9c22479',1,'Cluster']]],
  ['inmersion_5fimprimir_5festructura_8',['inmersion_imprimir_estructura',['../Cluster_8cc.html#abdb17fd4cecd9c0b3458cba712b6a387',1,'Cluster.cc']]]
];

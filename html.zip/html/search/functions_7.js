var searchData=
[
  ['prioritat_0',['Prioritat',['../classPrioritat.html#af2ad973a8bc814685bc8f05aaa3a2a8a',1,'Prioritat']]],
  ['prioritat_5fexisteix_5fproces_1',['prioritat_existeix_proces',['../classArea__de__espera.html#ac2e97f38fd0996ae07b1ddd0f5063543',1,'Area_de_espera']]],
  ['prioritat_5fte_5fprocessos_2',['prioritat_te_processos',['../classArea__de__espera.html#a9aa5edde8535ec11cbef35d881ddd78b',1,'Area_de_espera']]],
  ['proces_3',['Proces',['../classProces.html#a4d0ab1884d133bf380c6bbb580dcc853',1,'Proces']]]
];

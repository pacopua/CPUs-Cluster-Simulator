var searchData=
[
  ['capacitat_0',['capacitat',['../classCpu.html#a4bfda8eaab4988e20240ace423a1d21c',1,'Cpu']]]
];

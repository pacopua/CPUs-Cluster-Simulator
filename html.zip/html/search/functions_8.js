var searchData=
[
  ['tamaño_5fhueco_5fminimo_0',['tamaño_hueco_minimo',['../classCpu.html#ad1a4e5e24c742de64a39e01b5f74703c',1,'Cpu']]],
  ['te_5fprocessos_1',['te_processos',['../classCpu.html#a804976eb0d63bc0b8c3e571929a0b62d',1,'Cpu']]]
];

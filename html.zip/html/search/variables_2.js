var searchData=
[
  ['id_0',['ID',['../classCpu.html#a7c296c21446e0c0a6f5628c72af3f4d3',1,'Cpu::ID'],['../classProces.html#ae3680a8b552346b3c9fbd7f233fe0a0f',1,'Proces::ID']]]
];

var searchData=
[
  ['prioritat_0',['Prioritat',['../classPrioritat.html',1,'']]],
  ['proces_1',['Proces',['../classProces.html',1,'']]]
];

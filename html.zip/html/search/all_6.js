var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mapa_1',['mapa',['../classCluster.html#a63aa971f9297fc2487273fb1e8aac17e',1,'Cluster']]],
  ['mapa_5fforats_2',['mapa_forats',['../classCpu.html#a377309ef0ce535296ded84ebc221f6b4',1,'Cpu']]],
  ['mapa_5fposiciones_3',['mapa_posiciones',['../classCpu.html#a5c8ec1187650622d819f3f86c7eb2267',1,'Cpu']]],
  ['mapa_5fprocessos_4',['mapa_processos',['../classCpu.html#a694e019457c6d1d485d0b639358280f2',1,'Cpu']]],
  ['memoria_5flliure_5',['memoria_lliure',['../classCpu.html#ab89d686a77ec87c0b76b3198d69ad133',1,'Cpu']]],
  ['memreq_6',['memreq',['../classProces.html#a287c16342d31fb9451a8a4dd2655cd87',1,'Proces']]],
  ['modificar_5fcluster_7',['modificar_cluster',['../classCluster.html#a149f8bf9acccecfce34bfc4f5a09b282',1,'Cluster']]],
  ['modificar_5ftemps_8',['modificar_temps',['../classProces.html#aaba46505d9faf344bb33e755c574a4ba',1,'Proces']]]
];

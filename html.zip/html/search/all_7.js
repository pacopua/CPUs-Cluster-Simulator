var searchData=
[
  ['página_20principal_3a_0',['Página Principal:',['../index.html',1,'']]],
  ['prioritat_1',['Prioritat',['../classPrioritat.html',1,'Prioritat'],['../classPrioritat.html#af2ad973a8bc814685bc8f05aaa3a2a8a',1,'Prioritat::Prioritat()']]],
  ['prioritat_2ecc_2',['Prioritat.cc',['../Prioritat_8cc.html',1,'']]],
  ['prioritat_2ehh_3',['Prioritat.hh',['../Prioritat_8hh.html',1,'']]],
  ['prioritat_5fexisteix_5fproces_4',['prioritat_existeix_proces',['../classArea__de__espera.html#ac2e97f38fd0996ae07b1ddd0f5063543',1,'Area_de_espera']]],
  ['prioritat_5fte_5fprocessos_5',['prioritat_te_processos',['../classArea__de__espera.html#a9aa5edde8535ec11cbef35d881ddd78b',1,'Area_de_espera']]],
  ['prioritats_6',['prioritats',['../classArea__de__espera.html#a23b23c0baa15388e2e0d161b01b9bbd9',1,'Area_de_espera']]],
  ['proces_7',['Proces',['../classProces.html',1,'Proces'],['../classProces.html#a4d0ab1884d133bf380c6bbb580dcc853',1,'Proces::Proces()']]],
  ['proces_2ecc_8',['Proces.cc',['../Proces_8cc.html',1,'']]],
  ['proces_2ehh_9',['Proces.hh',['../Proces_8hh.html',1,'']]],
  ['proces_5fdenegats_10',['proces_denegats',['../classPrioritat.html#a1f43701526c298e5b72a2e5ab2c7ab2a',1,'Prioritat']]],
  ['proces_5fenviats_11',['proces_enviats',['../classPrioritat.html#a1d296ed877b23dba5c2fb6c859c94ba9',1,'Prioritat']]],
  ['processos_12',['processos',['../classPrioritat.html#a9e64678f4b000dc157c82afc0ffbacda',1,'Prioritat']]],
  ['program_2ecc_13',['program.cc',['../program_8cc.html',1,'']]]
];

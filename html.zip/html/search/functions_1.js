var searchData=
[
  ['baja_5fprioridad_0',['baja_prioridad',['../classArea__de__espera.html#ae047bbb1b009919d64d9e24a01d29ed9',1,'Area_de_espera']]],
  ['baja_5fproceso_5fprocesador_1',['baja_proceso_procesador',['../classCluster.html#a676c3b51cc495e678defb8a929c0bc51',1,'Cluster::baja_proceso_procesador()'],['../classCpu.html#aa3671be057fbb1c08fea3bb120e712c8',1,'Cpu::baja_proceso_procesador()']]],
  ['buscar_5fprocesador_2',['buscar_procesador',['../classCluster.html#a1722961907ee90405ba9b2f2fb95b821',1,'Cluster']]]
];

var searchData=
[
  ['id_0',['ID',['../classCpu.html#a7c296c21446e0c0a6f5628c72af3f4d3',1,'Cpu::ID'],['../classProces.html#ae3680a8b552346b3c9fbd7f233fe0a0f',1,'Proces::ID']]],
  ['imprimir_1',['imprimir',['../classProces.html#a65b5b63f01bc0be96d2be54ff90bc987',1,'Proces']]],
  ['imprimir_5farea_5fespera_2',['imprimir_area_espera',['../classArea__de__espera.html#abb8a42b756eb6ec839b1ad514eed3b43',1,'Area_de_espera']]],
  ['imprimir_5festructura_3',['imprimir_estructura',['../classCluster.html#ad6e93a4a1a6f2e9228b5e30962b4ac06',1,'Cluster']]],
  ['imprimir_5fid_4',['imprimir_ID',['../classCpu.html#ae4b77431b71b0cabd384566ebfe24d81',1,'Cpu']]],
  ['imprimir_5fprioridad_5',['imprimir_prioridad',['../classArea__de__espera.html#ade30d0c4340bbace809fdf5074c515ac',1,'Area_de_espera::imprimir_prioridad()'],['../classPrioritat.html#acbd167ca58481a599da536086981741b',1,'Prioritat::imprimir_prioridad()']]],
  ['imprimir_5fprocesador_6',['imprimir_procesador',['../classCluster.html#a2568d0369b17835721a85ead28637d5f',1,'Cluster::imprimir_procesador()'],['../classCpu.html#a5eb8b3c4af9d015bc41370cac5fabe1c',1,'Cpu::imprimir_procesador()']]],
  ['imprimir_5fprocesadores_7',['imprimir_procesadores',['../classCluster.html#afc3924fd1f4643746ec3757c7777d732',1,'Cluster']]],
  ['inmersio_5fmodificar_5fcluster_8',['inmersio_modificar_cluster',['../classCluster.html#abe760c9557b5aaabc8cfb921f9c22479',1,'Cluster']]],
  ['inmersion_5fimprimir_5festructura_9',['inmersion_imprimir_estructura',['../Cluster_8cc.html#abdb17fd4cecd9c0b3458cba712b6a387',1,'Cluster.cc']]]
];

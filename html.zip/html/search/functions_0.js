var searchData=
[
  ['añadir_5fproceso_0',['añadir_proceso',['../classPrioritat.html#ae5cd22c0ee4b6e4f8e2bcb306fb8309b',1,'Prioritat']]],
  ['ajustar_5fhuecos_1',['ajustar_huecos',['../classCpu.html#a5185c10e1a5a7a08e7302c0febb3e5f7',1,'Cpu']]],
  ['alta_5fprioridad_2',['alta_prioridad',['../classArea__de__espera.html#ab42b770642e4ed07d99812e15726a4d5',1,'Area_de_espera']]],
  ['alta_5fproceso_5fespera_3',['alta_proceso_espera',['../classArea__de__espera.html#aab5a3a3a96ce22e9bb9f781dca4adad5',1,'Area_de_espera']]],
  ['alta_5fproceso_5fprocesador_4',['alta_proceso_procesador',['../classCluster.html#a7bbb98bf3cf5dfe46aba2baa58e1b766',1,'Cluster::alta_proceso_procesador()'],['../classCpu.html#ac024e580d2a8167849ea1d6cf3c7320d',1,'Cpu::alta_proceso_procesador()']]],
  ['area_5fde_5fespera_5',['Area_de_espera',['../classArea__de__espera.html#a1915ffca48accdb8e446257a13146cd7',1,'Area_de_espera']]],
  ['asignar_5fvalores_5fcpu_6',['asignar_valores_cpu',['../classCpu.html#ac53dfd848db3d7b381386cce1ae48af8',1,'Cpu']]],
  ['avanzar_5ftiempo_7',['avanzar_tiempo',['../classCluster.html#ab56c23130c58c354ab095dfc5a7ce708',1,'Cluster::avanzar_tiempo()'],['../classCpu.html#a4b41934087a3ebfd4711dfc757634d88',1,'Cpu::avanzar_tiempo()']]]
];

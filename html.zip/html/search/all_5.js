var searchData=
[
  ['llegir_0',['llegir',['../classCpu.html#aaaf9692f387a2cc1bd9095b9528c7bab',1,'Cpu::llegir()'],['../classProces.html#ad13bb10589d8bf5307e789f246cbfb44',1,'Proces::llegir()']]],
  ['llegir_5farea_5fde_5fespera_1',['llegir_area_de_espera',['../classArea__de__espera.html#ae2b8641612bb6c80348073ddaf9bdf4a',1,'Area_de_espera']]],
  ['llegir_5fbintree_2',['llegir_BinTree',['../classCluster.html#a0fdbb320d3aba4d7eeaa72d7e92e7852',1,'Cluster']]]
];

var searchData=
[
  ['tamaño_5fhueco_5fminimo_0',['tamaño_hueco_minimo',['../classCpu.html#ad1a4e5e24c742de64a39e01b5f74703c',1,'Cpu']]],
  ['te_5fprocessos_1',['te_processos',['../classCpu.html#a804976eb0d63bc0b8c3e571929a0b62d',1,'Cpu']]],
  ['temps_2',['temps',['../classCluster.html#aa6bdd6d97615715f661d34935babac9d',1,'Cluster::temps'],['../classProces.html#a7b9c0db0212d9727e7c3c5b7fdd6ea5d',1,'Proces::temps']]]
];

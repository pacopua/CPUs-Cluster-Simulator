var searchData=
[
  ['prioritats_0',['prioritats',['../classArea__de__espera.html#a23b23c0baa15388e2e0d161b01b9bbd9',1,'Area_de_espera']]],
  ['proces_5fdenegats_1',['proces_denegats',['../classPrioritat.html#a1f43701526c298e5b72a2e5ab2c7ab2a',1,'Prioritat']]],
  ['proces_5fenviats_2',['proces_enviats',['../classPrioritat.html#a1d296ed877b23dba5c2fb6c859c94ba9',1,'Prioritat']]],
  ['processos_3',['processos',['../classPrioritat.html#a9e64678f4b000dc157c82afc0ffbacda',1,'Prioritat']]]
];
